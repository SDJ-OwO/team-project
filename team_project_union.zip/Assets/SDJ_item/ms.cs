using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class ms : MonoBehaviour
{
    public float duration = 10;
    float count;
    public GameObject layer1_enemy;
    public GameObject layer2_enemy;

    Vector2[] layer1 = {new Vector2(-1,1), new Vector2(6,1), new Vector2(8, 7), new Vector2(-6, -8), new Vector2(7, 13)};
    Vector2[] layer2 = {new Vector2(2, 9), new Vector2(10, 9), new Vector2(-6, 7), new Vector2(-1, -3.3f) };
    // Start is called before the first frame update
    void Start()
    {
        count = duration;
    }

    // Update is called once per frame
    void Update()
    {
        count = count - Time.deltaTime;
        //Debug.Log(count);
        if (count < 0)
        {
            int temp = Random.Range(1, 3);
            Vector2 offset = new Vector2(Random.Range(-0.1f, 0.1f), Random.Range(-0.1f, 0.1f));
            if (temp == 1)
            {
                Instantiate(layer1_enemy, layer1[Random.Range(0, 5)] + offset, Quaternion.Euler(0, 0, 0));
            }
            else if(temp == 2)
            {
                Instantiate(layer2_enemy, layer2[Random.Range(0, 4)] + offset, Quaternion.Euler(0, 0, 0));
            }
            count = duration;
        }
        //Debug.Log(layer1[Random.Range(0, 5)]);

    }
}
