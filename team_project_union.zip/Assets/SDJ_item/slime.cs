using System.Collections;
using System.Collections.Generic;
using System.Net;
using System.Threading;
using Unity.VisualScripting;

using UnityEngine;

public class slime : MonoBehaviour
{
    public Animator animator;
    public GameObject hitbox;
    //public GameObject hitbox1;



    public float speed;
    //public float high_speed;

    public float radius;
    public float attack_hs;
    public float attack_dist;
    float attack_pass = 0;
    float atk_count;
    float atk_duration = 2f;

    //bool test = true;

    Vector2 atk_dest;
    // Start is called before the first frame update
    void Start()
    {
        atk_count = attack_hs;
    }

    // Update is called once per frame
    void Update()
    {


        // ����
        if (attack_pass == 1)
        {
            atk_count -= Time.deltaTime;
            //Debug.Log(atk_count);
            if (atk_count <= 0)
            {
                speed *= 2f;
                atk_count = attack_hs;
                attack_pass = 2;
                animator.SetBool("attack", true);
                animator.SetBool("idle", false);
            }
            return;
        }



        // �������a
        Collider2D[] colliders = Physics2D.OverlapCircleAll(transform.position, radius);

        foreach( Collider2D item in colliders)
        {
            if(item.tag == "Player")
            {
                animator.SetBool("walk", true);
                animator.SetBool("sleep", false);
                //Debug.Log(item.transform.position);
                Vector2 player = item.transform.position;
                Vector2 enemy = transform.Find("position").transform.position;

                Vector2 dir = player - enemy;
                float distance = Vector2.Distance(player, enemy);
                
                

                if(attack_pass == 2)
                {
                    animator.SetBool("attack", true);
                    atk_duration -= Time.deltaTime;
                    if(atk_duration <= 0)
                    {
                        atk_duration = 2;
                        attack_pass = 0;
                        speed /= 2f;


                        animator.SetBool("attack", false);
                    }
                }

                // �l��
                transform.Translate(dir.normalized * speed * Time.deltaTime,Space.World );
                /*
                dir.Normalize();
                GetComponent<Rigidbody2D>().velocity = speed * dir;
                */
                if (dir.x > 0)
                {
                    transform.rotation = Quaternion.Euler(new Vector3(0, 0, 0));
                }
                else if(dir.x<0)
                {
                    transform.rotation = Quaternion.Euler(new Vector3(0, 180,0));
                }
                
                //Debug.Log(GetComponent<Rigidbody2D>().velocity);

                if (distance <= attack_dist && attack_pass==0)
                {
                    attack_pass = 1;
                    atk_dest = dir;
                    animator.SetBool("idle", true);
                }
                return;
            }



           
        }
        animator.SetBool("sleep", true);
        animator.SetBool("walk", false);
        animator.SetBool("idle", false);
        animator.SetBool("attack", false);
        attack_pass = 0;
        speed = 2;
    }






    public void OnTriggerEnter2D(Collider2D collision)
    {
        if(collision.tag == "bullet")
        {
            Destroy(gameObject);
        }
    }
    public void OnCollisionEnter2D(Collision2D collision)
    {
        if (collision.gameObject.tag == "enemy")
        {
            Physics2D.IgnoreCollision(GetComponent<Collider2D>(), collision.collider);
        }
    }
}
