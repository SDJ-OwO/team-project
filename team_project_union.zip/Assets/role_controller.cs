using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using Text = TMPro.TextMeshProUGUI;


public class role_controller : MonoBehaviour
{
    public GameManager manager;
    [SerializeField] int Hp;
    [SerializeField] GameObject HpBar;
    public Text scoreText;
    
    public Transform firePoint;
    public GameObject bulletPrefab;
    int score;
    // Start is called before the first frame update
    void Start()
    {
        score = 0;
        Hp = 10;
    }

    // Update is called once per frame
    void Update()
    {
        if (Hp == 9)
        {
            manager.GameOver(true);
            Hp = 10;
        }
        if (Input.GetButtonDown("Fire1"))
        {
            Shoot();
        }
    }


    public void OnTriggerEnter2D(Collider2D other)
    {

        //state = animator.GetCurrentAnimatorStateInfo(0);
        if (other.gameObject.tag == "box")
        {
            addscore(1);
            Destroy(other.gameObject);
        }
        if (other.gameObject.tag == "water")
        {
            Destroy(other.gameObject);
            ModifyHp(1);
        }
        if (other.gameObject.tag == "enemy")
        {
            AnimatorStateInfo state = other.GetComponent<Animator>().GetCurrentAnimatorStateInfo(0);
            if (state.IsName("Spin"))
            {
                Debug.Log("test");
                Destroy(other.gameObject);
                ModifyHp(-1);
            }

        }
    }
    void ModifyHp(int num)
    {
        Hp += num;
        if (Hp > 10)
        {
            Hp = 10;
        }
        else if (Hp < 0)
        {
            Hp = 0;
        }
        UpdateHpBar();
    }
    public void addscore(int n)
    {
        score += n;
        scoreText.text = "Box: " + score;
    }
    void UpdateHpBar()
    {
        for (int i = 0; i < HpBar.transform.childCount; i++)
        {
            if (Hp > i)
            {

                HpBar.transform.GetChild(i).gameObject.SetActive(true);
            }
            else
            {

                HpBar.transform.GetChild(i).gameObject.SetActive(false);
            }
        }
    }
    void Shoot()
    {
        Instantiate(bulletPrefab, firePoint.position, firePoint.rotation);
    }
}
