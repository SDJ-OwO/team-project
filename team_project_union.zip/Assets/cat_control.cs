using System.Collections;
using System.Collections.Generic;
using Unity.Mathematics;
using UnityEngine;
using Text = TMPro.TextMeshProUGUI;


public class cat_control : MonoBehaviour
{

    //public GameObject camera;
    public GameObject another_role;
    public GameManager manager;
    [SerializeField] int Hp;
    [SerializeField] GameObject HpBar;
    public Text scoreText;

    public Transform firePoint;
    public GameObject bulletPrefab;
    private int score;
    // Start is called before the first frame update
    void Start()
    {
        score = 0;
        Hp = 10;
        firePoint.rotation = Quaternion.Euler(new Vector3(0, 0, 270));
    }

    // Update is called once per frame
    void Update()
    {
        if (Hp == 0)
        {
            manager.GameOver(true);
            Hp = 10;
        }
        if (score > 2)
        {
            manager.Win();
            score = 0;
        }
        if (Input.GetKey(KeyCode.A))
        {
            firePoint.rotation = Quaternion.Euler(new Vector3(0,0, 180));
        }
        else if (Input.GetKey(KeyCode.D))
        {
            firePoint.rotation = Quaternion.Euler(new Vector3(0, 0, 0));
        }

        if (Input.GetKey(KeyCode.W))
        {
            firePoint.rotation = Quaternion.Euler(new Vector3(0, 0, 90));
        }
        else if (Input.GetKey(KeyCode.S))
        {
            firePoint.rotation = Quaternion.Euler(new Vector3(0, 0, 270));
        }

        if (Input.GetKeyDown(KeyCode.Space))
        {
            Shoot();
        }
    }

    public void OnTriggerStay2D(Collider2D other)
    {

        //state = animator.GetCurrentAnimatorStateInfo(0);
        if (other.gameObject.tag == "box")
        {
            addscore(1);
            Destroy(other.gameObject);
        }
        if (other.gameObject.tag == "water")
        {
            Destroy(other.gameObject);
            ModifyHp(1);
        }
        if (other.gameObject.tag == "enemy")
        {
            AnimatorStateInfo state = other.GetComponent<Animator>().GetCurrentAnimatorStateInfo(0);
            if (state.IsName("Spin"))
            {
                //Debug.Log("test");
                Destroy(other.gameObject);
                ModifyHp(-1);
            }

        }
    }
    void ModifyHp(int num)
    {
        Hp += num;
        if (Hp > 10)
        {
            Hp = 10;
        }
        else if (Hp < 0)
        {
            Hp = 0;
        }
        UpdateHpBar();
    }
    public void addscore(int n)
    {
        score += n;
        scoreText.text = "Box: " + score;
    }
    void UpdateHpBar()
    {
        for (int i = 0; i < HpBar.transform.childCount; i++)
        {
            if (Hp > i)
            {

                HpBar.transform.GetChild(i).gameObject.SetActive(true);
            }
            else
            {

                HpBar.transform.GetChild(i).gameObject.SetActive(false);
            }
        }
    }
    void Shoot()
    {
        Instantiate(bulletPrefab, firePoint.position, firePoint.rotation);
    }


    public void OnMouseOver()
    {
        another_role.GetComponent<SpriteRenderer>().color = new Color(1, 1, 1, 0.5f);
    }
    public void OnMouseExit()
    {
        another_role.GetComponent<SpriteRenderer>().color = new Color(1, 1, 1, 1f);
    }
    private void OnMouseDown()
    {
        Camera.main.gameObject.transform.SetParent(gameObject.transform);
        Camera.main.gameObject.transform.position = transform.position;
        Camera.main.orthographicSize = 3;
        another_role.SetActive(false);
        Time.timeScale = 1;
    }


}
