﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;
using Text=TMPro.TextMeshProUGUI;


namespace Cainos.PixelArtTopDown_Basic
{
    public class TopDownCharacterController : MonoBehaviour
    {
        public float speed;

        private Animator animator;
        [SerializeField] int Hp;
        [SerializeField] GameObject HpBar;
        public Text scoreText;
        int score;
        private void Start()
        {
            score=0;
            Hp=10;
            animator = GetComponent<Animator>();
        }


        private void Update()
        {
            Vector2 dir = Vector2.zero;
            if (Input.GetKey(KeyCode.A))
            {
                dir.x = -1;
                animator.SetInteger("Direction", 3);
            }
            else if (Input.GetKey(KeyCode.D))
            {
                dir.x = 1;
                animator.SetInteger("Direction", 2);
            }

            if (Input.GetKey(KeyCode.W))
            {
                dir.y = 1;
                animator.SetInteger("Direction", 1);
            }
            else if (Input.GetKey(KeyCode.S))
            {
                dir.y = -1;
                animator.SetInteger("Direction", 0);
            }

            dir.Normalize();
            animator.SetBool("IsMoving", dir.magnitude > 0);

            GetComponent<Rigidbody2D>().velocity = speed * dir;
        }
         public void OnTriggerEnter2D(Collider2D other)
         {
            
            //state = animator.GetCurrentAnimatorStateInfo(0);
            if(other.gameObject.tag=="box")
            {
                addscore(1);
                Destroy(other.gameObject);
            }
             if(other.gameObject.tag=="water")
            {
                Destroy(other.gameObject);
                ModifyHp(1);
            }
              if(other.gameObject.tag=="enemy")
            {
                AnimatorStateInfo state = other.GetComponent<Animator>().GetCurrentAnimatorStateInfo(0);
                if(state.IsName("Spin")){
                    Debug.Log("test");
                    Destroy(other.gameObject);
                    ModifyHp(-1);
                }
                
            }
         }
         void ModifyHp(int num)
         {
            Hp+=num;
            if(Hp>10)
            {
                Hp=10;
            }
            else if(Hp<0)
            {
                Hp=0;
            }
            UpdateHpBar();
         }
         public void addscore(int n)
        {
            score+=n;
            scoreText.text="Box: "+score;
        }
         void UpdateHpBar()
         {
            for(int i=0;i<HpBar.transform.childCount;i++)
            {
                if(Hp>i)
                {

                    HpBar.transform.GetChild(i).gameObject.SetActive(true);
                }
                else
                {

                    HpBar.transform.GetChild(i).gameObject.SetActive(false);
                }
            }
         }
    }
}
